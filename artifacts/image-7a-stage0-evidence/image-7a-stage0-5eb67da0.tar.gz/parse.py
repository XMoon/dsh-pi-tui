#!/usr/bin/env python3
"""Parse the captured outer terminal stream into ordered events.

Only the bytes the application really wrote are inspected: Kitty graphics
commands (with their payload reduced to a length + sha256, never the base64
itself) and the text signals whose effect Stage-0 measures.
"""
from __future__ import annotations
import argparse, hashlib, json

APC = b'\x1b_G'
ST = b'\x1b\\'
SIGNALS = [
    (b'\x1b[2J', 'clear-2J'),
    (b'\x1b[3J', 'clear-3J'),
    (b'\x1b[?1049h', 'alt-enter'),
    (b'\x1b[?1049l', 'alt-exit'),
    (b'\x1b[?2004l', 'terminal-stop-bracketed-paste-off'),
    (b'\x1b[?2004h', 'terminal-start-bracketed-paste-on'),
]


def parse(data: bytes) -> dict:
    commands = []
    index = 0
    while True:
        start = data.find(APC, index)
        if start < 0:
            break
        end = data.find(ST, start + len(APC))
        if end < 0:
            break
        body = data[start + len(APC):end]
        separator = body.find(b';')
        control_text = body[:separator] if separator >= 0 else body
        payload = body[separator + 1:] if separator >= 0 else b''
        controls = {}
        for part in control_text.split(b','):
            if not part:
                continue
            key, _, value = part.partition(b'=')
            if value:
                controls[key.decode('ascii', 'replace')] = value.decode('ascii', 'replace')
        commands.append({
            'offset': start,
            'a': controls.get('a'),
            'i': controls.get('i'),
            'p': controls.get('p'),
            'd': controls.get('d'),
            'c': controls.get('c'),
            'r': controls.get('r'),
            'q': controls.get('q'),
            'm': controls.get('m'),
            'C': controls.get('C'),
            'payload_len': len(payload),
            'payload_sha256': hashlib.sha256(payload).hexdigest()[:16] if payload else '',
            'controls': controls,
        })
        index = end + len(ST)

    signals = []
    for sequence, name in SIGNALS:
        cursor = 0
        while True:
            at = data.find(sequence, cursor)
            if at < 0:
                break
            signals.append({'offset': at, 'name': name})
            cursor = at + len(sequence)
    signals.sort(key=lambda entry: entry['offset'])

    timeline = [{'offset': entry['offset'], 'kind': 'apc', **{k: entry[k] for k in ('a', 'i', 'p', 'd', 'c', 'r', 'm')}} for entry in commands]
    timeline += [{'offset': entry['offset'], 'kind': 'signal', 'name': entry['name']} for entry in signals]
    timeline.sort(key=lambda entry: entry['offset'])

    return {
        'bytes': len(data),
        'commands': commands,
        'signals': signals,
        'timeline': timeline,
        'global_deletes': [c for c in commands if c['d'] in ('A', 'a', '') and c['a'] == 'd' and c['i'] is None],
        'counts': {
            'transmit': sum(1 for c in commands if c['a'] in ('t', 'T')),
            'place_only': sum(1 for c in commands if c['a'] == 'p'),
            'delete_image': sum(1 for c in commands if c['a'] == 'd' and c['d'] == 'I'),
            'delete_placement': sum(1 for c in commands if c['a'] == 'd' and c['d'] == 'i'),
            'delete_all_images': sum(1 for c in commands if c['a'] == 'd' and c['d'] == 'A'),
            'delete_all_placements': sum(1 for c in commands if c['a'] == 'd' and c['d'] == 'a'),
            'clear_2J': sum(1 for entry in signals if entry['name'] == 'clear-2J'),
            'clear_3J': sum(1 for entry in signals if entry['name'] == 'clear-3J'),
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('input')
    parser.add_argument('--out', required=True)
    args = parser.parse_args()
    with open(args.input, 'rb') as handle:
        data = handle.read()
    report = parse(data)
    with open(args.out, 'w') as handle:
        json.dump(report, handle, indent=2)
        handle.write('\n')
    print(json.dumps(report['counts'], sort_keys=True))


if __name__ == '__main__':
    main()
