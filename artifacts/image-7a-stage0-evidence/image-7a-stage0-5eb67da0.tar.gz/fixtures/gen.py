#!/usr/bin/env python3
"""Generate the Stage-0 fixture PNGs (solid colours + one oversized payload)."""
import os, struct, zlib

def write_png(path, w, h, pixel):
    raw = bytearray()
    for y in range(h):
        raw.append(0)
        for x in range(w):
            r, g, b = pixel(x, y)
            raw += bytes((r, g, b))
    def chunk(kind, data):
        return struct.pack('>I', len(data)) + kind + data + struct.pack('>I', zlib.crc32(kind + data) & 0xffffffff)
    ihdr = struct.pack('>IIBBBBB', w, h, 8, 2, 0, 0, 0)
    blob = b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', ihdr) + chunk(b'IDAT', zlib.compress(bytes(raw), 9)) + chunk(b'IEND', b'')
    with open(path, 'wb') as handle:
        handle.write(blob)
    return len(blob)

here = os.path.dirname(os.path.abspath(__file__))
write_png(os.path.join(here, 'A-red-64.png'), 64, 64, lambda x, y: (220, 30, 30))
write_png(os.path.join(here, 'B-blue-64.png'), 64, 64, lambda x, y: (30, 60, 220))
# A payload whose base64 exceeds one 4096-char chunk (multi-chunk transmit).
write_png(os.path.join(here, 'A-big.png'), 320, 240,
          lambda x, y: ((x * 7) % 256, (y * 5) % 256, (x * y) % 256))
for name in ('A-red-64.png', 'B-blue-64.png', 'A-big.png'):
    path = os.path.join(here, name)
    print(name, os.path.getsize(path), 'bytes -> base64', -(-os.path.getsize(path) // 3) * 4)
