#!/usr/bin/env node
/**
 * Image-7A PR1 Stage-0 proof adapter.
 *
 * Runs a REAL `ProcessTerminal` inside a real Kitty window, wraps it in the
 * PRODUCTION `KittyTerminalFacade` + `KittyGraphicsCore`, and mounts the real
 * vendored `TuiMainScreen` / `TuiAltScreen`. The only test-only pieces are the
 * root component (it decides which managed image is visible) and the control
 * channel; every terminal byte travels the production path.
 *
 * Commands arrive through a control file so the runner owns the timing and no
 * synthetic key input is needed.
 */
import { appendFileSync, existsSync, readFileSync, writeFileSync } from 'node:fs'
import {
	getCapabilities,
	ProcessTerminal,
	TuiAltScreen,
	TuiMainScreen,
	setCapabilities,
	type Component,
	type Terminal,
} from '@xmoon76/pi-tui'
import { KittyGraphicsCore } from '../../src/tui/graphics/kitty-core.ts'
import { KittyTerminalFacade } from '../../src/tui/graphics/kitty-terminal.ts'
import {
  NativeKittyImage,
  admitsNativeKitty,
  createNativeKittyGraphics,
  type NativeKittyGraphics,
} from '../../src/tui/graphics/native-image.ts'
import { ImageThumbnail } from '../../src/tui/components/media/image-thumbnail.ts'
import { ImageViewerPanel } from '../../src/tui/components/media/image-viewer.ts'
import { ImageLoader } from '../../src/client/media/image/loader.ts'

const CASE = process.env.S0_CASE ?? 'S0'
const SCENARIO = process.env.S0_SCENARIO ?? 's01-main'
const SCREEN = process.env.S0_SCREEN ?? 'main'
const DIR = process.env.S0_DIR!
const CONTROL = process.env.S0_CONTROL!
const EVENTS = process.env.S0_EVENTS!
const STAGE = process.env.S0_STAGE!
const IMG_A = process.env.S0_IMG_A!
const IMG_B = process.env.S0_IMG_B!
const ID_B = Number(process.env.S0_ID_B ?? 0x0d0e0f)
const PLACE_B = Number(process.env.S0_PLACE_B ?? 55)
const ESC = '\x1b'
/** A byte-identical pass-through probe: OSC 8, OSC 52, a non-delete APC, SGR. */
const INVARIANCE_PAYLOAD = `${ESC}]8;;https://example.com${ESC}\\link${ESC}]8;;${ESC}\\ ${ESC}]52;c;YWJj${ESC}\\ ${ESC}_Gi=123;payload-not-a-command${ESC}\\ ${ESC}[31mred${ESC}[0m`

const bytesA = readFileSync(IMG_A)
const base64A = bytesA.toString('base64')
const base64B = existsSync(IMG_B) ? readFileSync(IMG_B).toString('base64') : base64A

let seq = 0
function ev(type: string, extra: Record<string, unknown> = {}): void {
	appendFileSync(EVENTS, `${JSON.stringify({ seq: ++seq, t: new Date().toISOString(), case: CASE, screen: SCREEN, type, ...extra })}\n`)
}
function stage(line: string): void {
	appendFileSync(STAGE, `${CASE}:${line}\n`)
}

setCapabilities({ images: 'kitty', trueColor: true, hyperlinks: false })

const terminal: Terminal = new ProcessTerminal()
const core = new KittyGraphicsCore({ onEvent: (event) => ev('core', { ...event }) })
const facade = new KittyTerminalFacade(terminal, core)
// The product-shaped case goes through the REAL factory (admission included);
// every other case drives the Core directly for deterministic control.
const PRODUCT = SCENARIO === 's06-product'
const MIXED = SCENARIO === 's07-mixed'
const productGraphics: NativeKittyGraphics | undefined = PRODUCT ? createNativeKittyGraphics(terminal) : undefined
const screenTerminal: Terminal = productGraphics?.terminal ?? facade
ev('admission', {
	admits: admitsNativeKitty(),
	product: PRODUCT,
	hasGraphics: productGraphics !== undefined,
	capabilities: getCapabilities(),
	termProgram: process.env.TERM_PROGRAM,
	kittyWindowId: process.env.KITTY_WINDOW_ID,
	term: process.env.TERM,
	tmux: process.env.TMUX,
	zellij: process.env.ZELLIJ,
	sty: process.env.STY,
})

const PNG_W = 64
const PNG_H = 64

class Stage0Root implements Component {
	showA = true
	status = 0
	stageName = 'base'
	width = 80
	readonly imageA: NativeKittyImage

	constructor() {
		this.imageA = new NativeKittyImage(
			core,
			{ pngBase64: base64A, widthPx: PNG_W, heightPx: PNG_H },
			{ maxWidthCells: 30, maxHeightCells: 10, fallback: '[managed image fallback]' },
		)
	}

	render(width: number): string[] {
		this.width = width
		const lines: string[] = [`${CASE} stage0 (${SCENARIO})`, `screen=${SCREEN} width=${width}`]
		if (this.showA) {
			lines.push('')
			lines.push(...this.imageA.render(width))
		}
		for (let index = 0; index < this.status; index++) lines.push(`status ${index}`)
		lines.push(`S0:${CASE}:STAGE:${this.stageName}`)
		lines.push(`S0:${CASE}:PAINTED`)
		ev('render', { stage: this.stageName, width, lines: lines.length, showA: this.showA })
		return lines
	}

	invalidate(): void {
		this.imageA.invalidate()
	}

	dispose(): void {
		this.imageA.dispose()
	}
}

/** The product-shaped root: the REAL transcript thumbnail + viewer panel. */
class ProductRoot implements Component {
	showA = true
	status = 0
	stageName = 'base'
	width = 80
	imageA: NativeKittyImage | undefined
	readonly thumbnail: ImageThumbnail | undefined
	readonly viewer: ImageViewerPanel | undefined

	constructor(graphics: NativeKittyGraphics) {
		const loader = new ImageLoader(async () => ({ ref: {}, data: bytesA }))
		const ref = {
			attachmentId: 'att-a',
			mediaType: 'image/png' as const,
			bytes: bytesA.length,
			width: PNG_W,
			height: PNG_H,
			name: 'shot.png',
		}
		loader.load(ref)
		this.thumbnail = new ImageThumbnail(
			ref,
			loader,
			{ fallbackColor: (text: string) => text },
			() => {},
			undefined,
			undefined,
			undefined,
			graphics,
		)
		const viewerBytes = existsSync(IMG_B) ? readFileSync(IMG_B) : bytesA
		const viewerLoader = new ImageLoader(async () => ({ ref: {}, data: viewerBytes }))
		const viewerRef = {
			attachmentId: 'att-b',
			mediaType: 'image/png' as const,
			bytes: viewerBytes.length,
			width: PNG_W,
			height: PNG_H,
			name: 'view.png',
		}
		viewerLoader.load(viewerRef)
		this.viewer = new ImageViewerPanel({
			ref: viewerRef,
			scope: undefined,
			loader: viewerLoader,
			theme: { fallbackColor: (text: string) => text },
			requestRender: () => {},
			onClose: () => {},
			nativeGraphics: graphics,
		})
		this.viewer.setMaxRows(14)
	}

	render(width: number): string[] {
		this.width = width
		const lines: string[] = [`${CASE} product path`, '']
		if (this.showA && this.thumbnail !== undefined) lines.push(...this.thumbnail.render(width))
		if (this.showA && this.viewer !== undefined) lines.push(...this.viewer.render(width))
		for (let index = 0; index < this.status; index++) lines.push(`status ${index}`)
		lines.push(`S0:${CASE}:STAGE:${this.stageName}`)
		lines.push(`S0:${CASE}:PAINTED`)
		ev('render', { stage: this.stageName, width, lines: lines.length, showA: this.showA })
		return lines
	}

	invalidate(): void {
		this.thumbnail?.invalidate()
		this.viewer?.invalidate()
	}

	dispose(): void {
		this.thumbnail?.dispose()
		this.viewer?.dispose()
	}
}

let tui: TuiMainScreen | TuiAltScreen | undefined
let root: Stage0Root | ProductRoot | undefined
let stopped = false
/** The MIXED scenario's leased alternate screen, sharing THIS facade/Core. */
let mixedAlt: { screen: TuiAltScreen; image: NativeKittyImage } | undefined

function mount(): void {
	root = PRODUCT ? new ProductRoot(productGraphics!) : new Stage0Root()
	if (SCREEN === 'alt') {
		tui = new TuiAltScreen(screenTerminal, undefined, undefined, { mouse: false })
	} else {
		tui = new TuiMainScreen(screenTerminal)
	}
	tui.addChild(root)
	tui.start()
	stopped = false
	ev('screen_start', { scenario: SCENARIO, screen: SCREEN })
	stage(`START:${root.imageA?.imageId ?? 0}`)
	setTimeout(() => mark('initial'), PRODUCT ? 260 : 120)
}

function mark(reason: string): void {
	if (tui === undefined || stopped || root === undefined) return
	tui.renderNow()
	stage(`PAINTED:${reason}`)
	ev('frame_written', { reason, width: root.width, imageId: root.imageA?.imageId ?? 0 })
}

function stopTui(preserve: boolean): void {
	if (tui === undefined || stopped) return
	stopped = true
	ev('screen_stop_begin', { preserve })
	tui.stop({ preserveScreen: preserve })
	ev('screen_stopped', { preserve })
}

function foreignPlace(row: number): void {
	facade.write(`${ESC}[${row};1H${ESC}_Ga=T,f=100,q=2,i=${ID_B},p=${PLACE_B},c=8,r=3,C=1;${base64B}${ESC}\\`)
	ev('foreign_placed', { imageId: ID_B, placement: PLACE_B, row })
}

function foreignRetire(): void {
	facade.write(`${ESC}_Ga=d,d=I,i=${ID_B},q=2${ESC}\\`)
	ev('foreign_retire_written', { imageId: ID_B })
}

function clearSequence(kind: string): string {
	if (kind === 'none') return ''
	if (kind === '2j') return `${ESC}[2J`
	if (kind === '3j') return `${ESC}[3J`
	if (kind === '2j3j') return `${ESC}[2J${ESC}[3J`
	throw new Error(`unknown clear ${kind}`)
}

/** A raw placement that bypasses the facade: it can only paint when Kitty
 *  itself still holds the image data (that is the measurement). */
function probePlacement(withTransmit: boolean): void {
	if (root === undefined) return
	const imageA = root.imageA
	if (imageA === undefined) {
		ev('probe_unavailable', {})
		return
	}
	const imageId = imageA.imageId
	const body = imageA.paintedBodyAt(root.width)
	if (imageId === undefined || body === undefined) {
		ev('probe_unavailable', {})
		return
	}
	const place = `${ESC}[18;1H${ESC}_Ga=p,i=${imageId},p=99,c=${body.columns},r=${body.rows},C=1,q=2${ESC}\\`
	const transmit = withTransmit ? `${ESC}_Ga=t,f=100,i=${imageId},q=2;${base64A}${ESC}\\` : ''
	terminal.write(transmit + place)
	ev(withTransmit ? 'probe_transmit_place' : 'probe_place_only', { imageId, columns: body.columns, rows: body.rows })
}

function handle(line: string): void {
	const [command, ...rest] = line.trim().split(/\s+/)
	const argument = rest.join(' ')
	if (root === undefined) return
	if (PRODUCT && root instanceof ProductRoot) {
		switch (command) {
			case 'status':
				root.status = Number(argument || 1)
				root.stageName = `status-${root.status}`
				mark('status')
				return
			case 'hide-a':
				root.showA = false
				root.stageName = 'hide-a'
				mark('hide-a')
				return
			case 'show-a':
				root.showA = true
				root.stageName = 'show-a'
				mark('show-a')
				return
			case 'quit':
				ev('quit', {})
				setTimeout(() => process.exit(0), 150)
				return
		}
	}
	switch (command) {
		case 'status':
			root.status = Number(argument || 1)
			root.stageName = `status-${root.status}`
			mark('status')
			return
		case 'hide-a':
			root.showA = false
			root.stageName = 'hide-a'
			mark('hide-a')
			return
		case 'show-a':
			root.showA = true
			root.stageName = 'show-a'
			mark('show-a')
			return
		case 'render':
			mark('manual')
			return
		case 'foreign':
			foreignPlace(Number(argument || 12))
			return
		case 'retire-b':
			foreignRetire()
			return
		case 'retire-a':
			root.imageA?.dispose()
			root.showA = false
			root.stageName = 'retire-a'
			ev('core_retire_a_requested', {})
			mark('retire-a')
			return
		case 'upload-only': {
			const image = core.register({ pngBase64: base64A, widthPx: PNG_W, heightPx: PNG_H })
			if (image === undefined) {
				ev('upload_only_refused', {})
				return
			}
			facade.write(core.transmissionFor(image.imageId, 'main'))
			ev('upload_only_written', { imageId: image.imageId })
			return
		}
		case 'clear': {
			const kind = argument || 'none'
			facade.write(clearSequence(kind))
			ev('clear_written', { kind })
			return
		}
		case 'inject-text':
			facade.write(INVARIANCE_PAYLOAD)
			ev('injected_text', { bytes: Buffer.byteLength(INVARIANCE_PAYLOAD), payload: INVARIANCE_PAYLOAD })
			return
		case 'probe-place':
			probePlacement(false)
			return
		case 'probe-transmit-place':
			probePlacement(true)
			return
		case 'stop':
			stopTui(false)
			return
		case 'stop-preserve':
			stopTui(true)
			return
		case 'enter-alt': {
			const image = new NativeKittyImage(
				core,
				{ pngBase64: existsSync(IMG_B) ? readFileSync(IMG_B).toString('base64') : base64A, widthPx: PNG_W, heightPx: PNG_H },
				{ maxWidthCells: 20, maxHeightCells: 6, fallback: '[alt image fallback]' },
			)
			const screen = new TuiAltScreen(screenTerminal, undefined, undefined, { mouse: false })
			const altRoot: Component = {
				render(width: number): string[] {
					return ['alt viewer A+B', '', ...image.render(width), '', 'alt tail']
				},
				invalidate(): void {
					image.invalidate()
				},
				dispose(): void {
					image.dispose()
				},
			}
			screen.addChild(altRoot)
			screen.start()
			mark('enter-alt')
			screen.renderNow()
			mixedAlt = { screen, image }
			ev('mixed_alt_entered', { imageId: image.imageId ?? 0 })
			return
		}
		case 'leave-alt': {
			if (mixedAlt === undefined) return
			mixedAlt.screen.stop()
			mixedAlt = undefined
			ev('mixed_alt_left', {})
			mark('leave-alt')
			return
		}
		case 'stop-force':
			// Deliberately re-stop the SAME screen (no runner-side guard): the
			// production facade must stay idempotent.
			if (tui !== undefined) {
				ev('screen_stop_forced', {})
				tui.stop({ preserveScreen: false })
			}
			return
		case 'start': {
			root?.imageA?.dispose()
			mount()
			return
		}
		case 'quit':
			ev('quit', {})
			setTimeout(() => process.exit(0), 150)
			return
		default:
			ev('unknown_command', { line: line.trim() })
	}
}

writeFileSync(`${DIR}/input-plan.json`, `${JSON.stringify({
	schema: 'image-7a-stage0-plan-v1',
	case: CASE,
	scenario: SCENARIO,
	screen: SCREEN,
	fixture: IMG_A,
	fixtureBytes: bytesA.length,
	placement: 'a=p,C=1,i=<core id>,p=<core placement>,c,r,q=2;',
}, null, 2)}\n`)
ev('adapter_start', { scenario: SCENARIO, screen: SCREEN, fixtureBytes: bytesA.length })
mount()

let offset = 0
setInterval(() => {
	if (!existsSync(CONTROL)) return
	const data = readFileSync(CONTROL, 'utf8')
	if (data.length <= offset) return
	const chunk = data.slice(offset)
	offset = data.length
	for (const line of chunk.split('\n')) if (line.trim() !== '') handle(line)
}, 100)

process.on('unhandledRejection', (error) => ev('unhandled_rejection', { error: String(error) }))
process.on('SIGTERM', () => {
	try {
		stopTui(true)
	} finally {
		process.exit(0)
	}
})
