#!/usr/bin/env python3
"""Image-7A PR1 Stage-0 runner: one real Kitty window per case.

The window runs the production adapter inside `kitty script`, so the captured
`outer.bin` is the byte stream the terminal really received. Commands are
delivered through a control file (no synthetic key input), and screenshots are
taken of the case's own OS window only.
"""
from __future__ import annotations
import argparse, json, os, shutil, subprocess, time
from datetime import datetime, timezone

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(os.path.dirname(HERE))
CASES = os.path.join(HERE, 'cases')
FIX = os.path.join(HERE, 'fixtures')
ADAPTER = os.path.join(HERE, 'adapter.mts')
PARSER = os.path.join(HERE, 'parse.py')
RUNNER = os.path.join(HERE, 'runner-env.json')
DISPLAY = os.environ.get('DISPLAY', ':0')
ENV = {k: v for k, v in os.environ.items()
       if k not in {'TMUX', 'ZELLIJ', 'STY', 'KITTY_LISTEN_ON', 'KITTY_WINDOW_ID', 'KITTY_PID', 'DISPLAY'}}
ENV['DISPLAY'] = DISPLAY


def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec='seconds')


def write_json(path: str, payload: object) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'w') as handle:
        json.dump(payload, handle, indent=2)
        handle.write('\n')


def wait_file_contains(path: str, marker: str, timeout: float = 25.0) -> bool:
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            with open(path, 'rb') as handle:
                if marker.encode() in handle.read():
                    return True
        except OSError:
            pass
        time.sleep(0.1)
    return False


class Case:
    def __init__(self, case_id: str, scenario: str, screen: str, fixture: str = 'A-red-64.png', two: bool = False):
        self.case_id = case_id
        self.scenario = scenario
        self.screen = screen
        self.fixture = os.path.join(FIX, fixture)
        self.foreign = os.path.join(FIX, 'B-blue-64.png') if two else ''
        self.dir = os.path.join(CASES, case_id)
        self.title = f'S0-{case_id}-{int(time.time())}-{os.getpid()}'
        self.proc = None
        self.wid = None
        self.shots: list[str] = []
        self.started = now()
        self.log = None

    def setup(self) -> None:
        if os.path.isdir(self.dir):
            shutil.rmtree(self.dir)
        os.makedirs(self.dir)
        for name in ['control.txt', 'stage.log', 'stage-events.jsonl', 'wire-capture.bin']:
            open(os.path.join(self.dir, name), 'wb').close()
        self.control = os.path.join(self.dir, 'control.txt')
        self.stage = os.path.join(self.dir, 'stage.log')
        self.events = os.path.join(self.dir, 'stage-events.jsonl')
        self.trigger = os.path.join(self.dir, 'trigger')
        env = (f"S0_CASE='{self.case_id}' S0_SCENARIO='{self.scenario}' S0_SCREEN='{self.screen}' "
               f"S0_DIR='{self.dir}' S0_CONTROL='{self.control}' S0_STAGE='{self.stage}' "
               f"S0_EVENTS='{self.events}' S0_IMG_A='{self.fixture}' S0_IMG_B='{self.foreign}'")
        script = os.path.join(self.dir, 'run.sh')
        with open(script, 'w') as handle:
            handle.write("#!/bin/bash\n"
                         f"while [ ! -f '{self.trigger}' ]; do sleep 0.05; done\n"
                         f"cd '{REPO}'\n"
                         f"exec env {env} node --import tsx/esm '{ADAPTER}'\n")
        os.chmod(script, 0o700)
        self.log = open(os.path.join(self.dir, 'kitty.log'), 'wb')
        self.proc = subprocess.Popen(
            ['kitty', '--config', 'NONE', '--title', self.title,
             '-o', 'allow_remote_control=no', '-o', 'font_size=13',
             'script', '-q', '-f', '-c', f"bash '{script}'",
             os.path.join(self.dir, 'outer.bin')],
            env=ENV, stdout=self.log, stderr=subprocess.STDOUT)
        deadline = time.time() + 20
        while time.time() < deadline:
            result = subprocess.run(['xdotool', 'search', '--name', f'^{self.title}$'],
                                    capture_output=True, text=True, env=ENV)
            windows = [line for line in result.stdout.splitlines() if line.strip()]
            if windows:
                self.wid = windows[0]
                break
            time.sleep(0.2)
        if not self.wid:
            raise RuntimeError(f'window timeout for {self.case_id}')
        subprocess.run(['xdotool', 'windowsize', self.wid, '1000', '700'], env=ENV)
        time.sleep(0.5)
        open(self.trigger, 'wb').close()
        if not wait_file_contains(self.stage, f'{self.case_id}:PAINTED:initial', 30):
            raise RuntimeError(f'initial paint timeout for {self.case_id}')

    def snap(self, name: str) -> None:
        time.sleep(0.45)
        out = os.path.join(self.dir, f'{name}.png')
        result = subprocess.run(['maim', '-i', self.wid, '-f', 'png', out], env=ENV,
                                capture_output=True, text=True)
        if result.returncode == 0:
            self.shots.append(f'{name}.png')

    def send(self, command: str) -> None:
        with open(self.control, 'a') as handle:
            handle.write(command + '\n')

    def resize(self, width: int, height: int = 700) -> None:
        subprocess.run(['xdotool', 'windowsize', self.wid, str(width), str(height)], env=ENV)

    def cleanup(self) -> None:
        if self.proc and self.proc.poll() is None:
            self.proc.terminate()
            try:
                self.proc.wait(timeout=3)
            except subprocess.TimeoutExpired:
                self.proc.kill()
        outer = os.path.join(self.dir, 'outer.bin')
        if os.path.exists(outer) and os.path.getsize(outer) > 0:
            shutil.copyfile(outer, os.path.join(self.dir, 'raw-outer.bin'))
            subprocess.run(['python3', PARSER, outer, '--out', os.path.join(self.dir, 'protocol.json')],
                           capture_output=True)
        write_json(os.path.join(self.dir, 'command.json'), {
            'case': self.case_id, 'scenario': self.scenario, 'screen': self.screen,
            'fixture': os.path.basename(self.fixture), 'started_at': self.started,
            'finished_at': now(), 'screenshots': self.shots,
            'argv': 'kitty --config NONE --title <case> script -q -f -c <adapter> outer.bin',
        })

    def close(self) -> None:
        self.cleanup()
        if self.log is not None:
            self.log.close()


def run(case: Case, actions) -> None:
    case.setup()
    try:
        case.snap('00-before')
        actions(case)
        case.send('quit')
        time.sleep(0.4)
    finally:
        case.close()


def s0_1_main(c: Case) -> None:
    c.snap('01-initial')
    c.send('status 1')
    time.sleep(0.6)
    c.snap('02-text-update')
    c.send('hide-a')
    time.sleep(0.8)
    c.snap('03-hidden')
    c.send('show-a')
    time.sleep(0.8)
    c.snap('04-shown')
    c.send('render')
    time.sleep(0.5)
    c.snap('05-repeat')
    c.resize(780, 700)
    time.sleep(0.9)
    c.snap('06-resized-narrow')
    c.resize(1000, 700)
    time.sleep(0.9)
    c.snap('07-resized-back')
    c.send('retire-a')
    time.sleep(0.8)
    c.snap('08-retired')
    c.send('stop')
    time.sleep(0.6)
    c.snap('09-stopped')


def s0_2_foreign_first(c: Case) -> None:
    c.send('foreign 16')
    time.sleep(1.0)
    c.snap('01-both-visible')
    c.send('render')
    time.sleep(0.5)
    c.snap('02-after-plain-refresh')
    c.send('retire-b')
    time.sleep(0.8)
    c.snap('03-after-foreign-retire')
    c.send('stop')
    time.sleep(0.5)


def s0_2_core_first(c: Case) -> None:
    c.send('foreign 16')
    time.sleep(1.0)
    c.snap('01-both-visible')
    c.send('retire-a')
    time.sleep(0.9)
    c.snap('02-after-core-retire')
    c.send('stop')
    time.sleep(0.5)


def s0_2_2j_control(c: Case) -> None:
    c.send('foreign 16')
    time.sleep(1.0)
    c.snap('01-both-visible')
    c.send('clear 2j')
    time.sleep(0.6)
    c.snap('02-after-2j')
    c.send('stop')
    time.sleep(0.5)


def s0_3_alt(c: Case) -> None:
    c.snap('01-base')
    c.send('upload-only')
    time.sleep(0.6)
    c.snap('02-upload-only')
    c.send('stop')
    time.sleep(0.8)
    c.snap('03-after-stop')
    c.send('start')
    time.sleep(1.4)
    c.snap('04-after-reenter')
    c.send('stop')
    time.sleep(0.8)
    c.snap('05-after-second-stop')
    c.send('stop')
    time.sleep(0.6)
    c.snap('06-after-double-stop')
    c.send('stop-force')
    time.sleep(0.6)
    c.snap('07-after-forced-stop')


def s0_3_main(c: Case) -> None:
    c.snap('01-base')
    c.send('upload-only')
    time.sleep(0.6)
    c.snap('02-upload-only')
    c.send('stop-preserve')
    time.sleep(0.8)
    c.snap('03-after-stop-preserve')
    c.send('start')
    time.sleep(1.4)
    c.snap('04-after-restart')
    c.send('stop')
    time.sleep(0.8)
    c.snap('05-after-second-stop')
    c.send('stop')
    time.sleep(0.6)
    c.snap('06-after-double-stop')
    c.send('stop-force')
    time.sleep(0.6)
    c.snap('07-after-forced-stop')


def make_s0_4(variant: str):
    def action(c: Case) -> None:
        c.snap('01-initial')
        c.send(f'clear {variant}')
        time.sleep(0.6)
        c.snap('02-after-clear')
        c.send('probe-place')
        time.sleep(0.7)
        c.snap('03-after-clear-place-only')
        c.send('probe-transmit-place')
        time.sleep(0.7)
        c.snap('04-after-retransmit-place')
        c.send('hide-a')
        time.sleep(0.6)
        c.send('show-a')
        time.sleep(0.8)
        c.snap('05-after-production-rerender')
        c.send('status 1')
        time.sleep(0.7)
        c.snap('06-after-text-update')
        c.send('stop')
        time.sleep(0.5)
    return action


def s0_6_product(c: Case) -> None:
    c.snap('01-initial')
    c.send('status 1')
    time.sleep(0.7)
    c.snap('02-text-update')
    c.send('hide-a')
    time.sleep(0.8)
    c.snap('03-hidden')
    c.send('show-a')
    time.sleep(0.9)
    c.snap('04-shown')
    c.send('stop')
    time.sleep(0.5)


def s0_7_mixed(c: Case) -> None:
    c.snap('01-main-visible')
    c.send('enter-alt')
    time.sleep(1.2)
    c.snap('02-alt-visible')
    c.send('leave-alt')
    time.sleep(1.2)
    c.snap('03-back-on-main')
    c.send('status 1')
    time.sleep(0.8)
    c.snap('04-main-text-update')
    c.send('stop')
    time.sleep(0.5)


def s0_5_permission(c: Case) -> None:
    c.send('foreign 16')
    time.sleep(1.0)
    c.snap('01-both-visible')
    c.send('inject-text')
    time.sleep(0.5)
    c.snap('02-after-text')
    c.send('retire-b')
    time.sleep(0.8)
    c.snap('03-after-foreign-retire')
    c.send('retire-a')
    time.sleep(0.9)
    c.snap('04-after-core-retire')
    c.send('stop')
    time.sleep(0.5)


CASES_MAP = {
    'S0-1-main': ('s01-main', 'main', 'A-red-64.png', False, s0_1_main),
    'S0-1-main-mid': ('s01-main-mid', 'main', 'A-mid-96.png', False, s0_1_main),
    'S0-2-foreign-first': ('s02-alt', 'alt', 'A-red-64.png', True, s0_2_foreign_first),
    'S0-2-core-first': ('s02-alt', 'alt', 'A-red-64.png', True, s0_2_core_first),
    'S0-2-2j-control': ('s02-alt', 'alt', 'A-red-64.png', True, s0_2_2j_control),
    'S0-3-alt': ('s03-alt', 'alt', 'A-red-64.png', False, s0_3_alt),
    'S0-3-main': ('s03-main', 'main', 'A-red-64.png', False, s0_3_main),
    'S0-4-none': ('s04-clear', 'main', 'A-red-64.png', False, make_s0_4('none')),
    'S0-4-2j': ('s04-clear', 'main', 'A-red-64.png', False, make_s0_4('2j')),
    'S0-4-3j': ('s04-clear', 'main', 'A-red-64.png', False, make_s0_4('3j')),
    'S0-4-2j3j': ('s04-clear', 'main', 'A-red-64.png', False, make_s0_4('2j3j')),
    'S0-5-permission': ('s05-permission', 'alt', 'A-red-64.png', True, s0_5_permission),
    'S0-6-product': ('s06-product', 'main', 'A-red-64.png', True, s0_6_product),
    'S0-7-mixed': ('s07-mixed', 'main', 'A-red-64.png', True, s0_7_mixed),
}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('case', nargs='+')
    args = parser.parse_args()
    head = subprocess.run(['git', 'rev-parse', 'HEAD'], capture_output=True, text=True, cwd=REPO).stdout.strip()
    status = subprocess.run(['git', 'status', '--short'], capture_output=True, text=True, cwd=REPO).stdout.strip()
    write_json(RUNNER, {
        'display': DISPLAY, 'repo': REPO, 'head': head, 'dirty': status,
        'cases': args.case, 'kitty': subprocess.run(['kitty', '--version'], capture_output=True, text=True, env=ENV).stdout.splitlines()[:1],
        'node': subprocess.run(['node', '--version'], capture_output=True, text=True).stdout.strip(),
        'started_at': now(),
    })
    for case_id in args.case:
        if case_id not in CASES_MAP:
            raise SystemExit(f'unknown case {case_id}')
        scenario, screen, fixture, two, action = CASES_MAP[case_id]
        case = Case(case_id, scenario, screen, fixture, two)
        print('RUN', case_id, flush=True)
        run(case, action)
        print('DONE', case_id, flush=True)


if __name__ == '__main__':
    main()
