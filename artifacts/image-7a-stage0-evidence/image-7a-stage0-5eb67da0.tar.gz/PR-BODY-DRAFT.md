## What changed

Inline Kitty images were owned by three different places on one physical
terminal: the vendored main screen tracked per-line image ids and emitted
`d=I`, the alternate screen kept its own uploaded map and emitted global
`d=A`/`d=a` on stop/redraw, and every `Image` minted its own id. The global
forms also reach images another program painted into the same buffer.

This PR makes the client the single owner of its own images:

- **`src/tui/graphics/kitty-native.ts`** — the Native wire (quiet transmit
  chunks, `a=p,C=1` anchor with its reserved rows, scoped delete forms) plus the
  pure cell geometry, cross-checked against the real fork `Image.render()`.
- **`src/tui/graphics/kitty-core.ts`** — one ledger per physical terminal:
  per-buffer upload residency, placements, retirement, and a monotonic id range
  (never re-used, ownership decidable in O(1)). The budget bounds only the
  Core's ACTIVE working set (payload + estimated decoded footprint); there is
  no cumulative id quota.
- **`src/tui/graphics/kitty-terminal.ts`** — the `Terminal` facade both screens
  write through. It is a stream observer for this one protocol family: a legacy
  per-id delete of a managed image becomes a scoped placement removal, a legacy
  global delete (including the protocol-default bare `a=d`) becomes the same
  operations scoped to the buffer that emitted it, a foreign per-id delete
  passes through byte-for-byte, and every other byte (text, OSC 8/52, OSC 1337,
  mouse/keyboard modes, foreign APCs) is written unchanged. Graphics commands
  split across `Terminal.write()` boundaries — including a split inside the
  `ESC _G` introducer — are rejoined before the permission decision.
- Residency is tracked PER SCREEN BUFFER (Kitty keeps the main and the alternate
  screen's images apart), so a leased alternate screen's release can never take
  the main screen's images or scrollback with it.
- **`src/tui/graphics/native-image.ts`** — the `NativeKittyImage` component
  (one placement anchor + blank rows, no terminal IO in `render()`) and the
  one-per-terminal factory with the narrow admission rule.
- The five first-party native consumers now paint through the Core:
  transcript thumbnail (PNG and the Image-6A JPEG/WebP derivative), draft
  composer preview, image Viewer, SVG thumbnail and SVG Viewer. iTerm2, every
  other terminal and every non-Kitty path keep the legacy `Image`/text
  fallback. TSP is untouched.

`docs/architecture/terminal-output.md` gains the durable ownership contract.

## Stage-0 (blocking gates) — PASS

Real Kitty 0.41.1 on WSLg, real `TuiMainScreen`/`TuiAltScreen` + the real
facade/Core, raw outer bytes (`kitty script`) and per-case screenshots. Report
and artifacts: `temp/image-7a-stage0/` (not committed).

| Gate | Result |
|---|---|
| S0-1 valid line, Main hide/re-show without resize, multi-chunk quiet transmit | PASS |
| S0-2 same Alt buffer, foreign and managed `d=I` isolated in both directions | PASS |
| S0-3 automatic stop cleanup before `terminal.stop()`, new ids on re-entry, idempotent double stop | PASS |
| S0-4 `none` / `2J` / `3J` / `2J+3J` fresh-state comparison | PASS (see 3J note) |
| S0-5 permission trace + text/OSC invariance | PASS |
| S0-6 consumer sufficiency | PASS — no fork change required; `packages/pi-tui/**` is untouched |
| Main + leased Alt on one Core: Alt exit never touches Main | PASS (`S0-7-mixed`: alt stop deletes only the alt id; Main's image stays visible with no re-transmit) |

**Measured, not assumed:** on Kitty 0.41.1 a bare `CSI 3J` leaves the visible
screen empty AND the uploaded image data unusable, so it invalidates exactly
like `2J`; the production path re-transmits after both and not after `none`.

## Verification (run locally on this snapshot)

- `pnpm build`, `pnpm typecheck` — green.
- New suites: `test/tui/kitty-native-protocol.test.ts` (byte/geometry),
  `test/tui/kitty-graphics-owner.test.ts` (permission/lifecycle/working-set
  budget/write-failure/admission), `test/integration/kitty-native-screen.test.ts`
  (real main/alt writer, real transcript thumbnail, real `TuiApp` wiring, 100
  sequential thumbnails on a real screen).
- Affected client suites (thumbnail, draft preview, viewer, SVG, 6B, transcript)
  — 131 tests green in the targeted batch.
- Gates: architecture, boundary, keybindings, pi-divergence-ledger,
  pi-vendor-diff `--strict` (no fork change), pi-surface-compat, temp-hygiene,
  production-reads, naming, session-events — all green.

## Resource lifetime (Owner-adjudicated contract)

- A **painted** image is terminal-retained. When its occurrence goes away
  (component dispose, transcript trim/rebuild, screen stop) the Core drops its
  own payload copy and keeps the id — never re-used, and never hard-deleted by
  the Core, because the pixels may still be in the viewport or the scrollback.
- A **never-placed** upload is a pure pending byte set and is released by its
  own id at the next write / at stop.
- **Main stop never sends `d=I`** in either `preserveScreen` mode (the fork only
  repositions the cursor). **Alt stop releases the ids it placed, and only
  those.**
- The Core bounds only its own ACTIVE working set (pending uploads and the
  re-transmittable payload cache: 64 MiB base64 / 256 MiB estimated decoded
  footprint). **There is no cumulative image-id quota** (Owner amendment
  2026-10-27): the main screen keeps its scrollback, so a session legitimately
  displays more images over time and the 33rd/64th/100th must never fall back
  because of the ones before it. A painted occurrence leaves the active set,
  keeps no payload, and never re-uses its id; a fixed 256-id memory window keeps
  a late legacy delete recognisable as a placement removal. The terminal may
  keep that image data — the accepted cost of preserving the current visible
  behavior, not claimed as reclaimed memory.

## Known limits / not claimed

- No tmux pixel path (that is the next PR), no new setting, no TSP change.
- Full `verify:prepush`, `compat:dsh:npm`, tarball/startup smokes and the
  migration smokes run at the stage boundary; results will be recorded here.
- A whole-application real-session L6 run with Host attachments is NOT part of
  this PR's evidence; the E2 integration plus the real-GUI Stage-0 and
  product-shaped consumer cases cover the seam.

## Review trail

Independent reviewer (dedicated review route) ran four rounds on this branch:

| Round | Findings | Disposition |
|---|---|---|
| 1 | F1 cross-screen global delete freed Main images; F2 graphics introducer split across `write()` bypassed the gate; F3 `preserveScreen`-based Main cleanup | fixed: per-buffer residency; trailing introducer/signal holdback; Owner-adjudicated terminal retention |
| 2 | write failure could leave the ledger believing bytes landed; 32-id cap excluded retained ids | fixed: residency rollback + rethrow; retire take/commit/rollback; Owner replaced the id cap with a working-set budget |
| 3 | retained-id ring could forget an id (>256 retained ids); ids could be re-used | fixed: contiguous forward-only id range (exact ownership, never wraps) |
| 4 | stop cleanup wrote after deleting accounting; ambiguous placement cleanup; foreign pass-through under the id scheme | stop cleanup now take/commit/rollback; ambiguous placements retained per the Owner ruling; foreign ids outside the range pass through byte-for-byte |

The one item not closed by code is an explicit Owner adjudication: an AMBIGUOUS placement (the write threw after it may have painted) is retained rather than deleted, because the Owner froze "an image that may be referenced by viewport/scrollback is never freed by Core cleanup".
