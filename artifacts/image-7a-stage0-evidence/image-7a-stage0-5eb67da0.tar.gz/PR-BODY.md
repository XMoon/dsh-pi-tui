## Summary

Inline Kitty images had three different owners on one physical terminal: the
vendored main screen tracked per-line image ids and emitted `d=I`, the alternate
screen kept its own uploaded map and emitted global `d=A`/`d=a` on stop/redraw,
and every `Image` minted its own id. The global forms also reach images another
program painted into the same buffer, and no component could tell a legacy
writer's "this row changed" delete apart from an ownership decision.

This PR makes the Client the single owner of its own images:
`src/tui/graphics/` adds one `KittyGraphicsCore` per physical terminal, a
`KittyTerminalFacade` both screens write through, and a `NativeKittyImage`
component. The five first-party native consumers (transcript thumbnail incl. the
Image-6A JPEG/WebP derivative, draft composer preview, image Viewer, SVG
thumbnail and SVG viewer) paint through the Core on a directly attached Kitty;
every other terminal, iTerm2, TSP and the legacy paths are untouched.

## Scope

- Changed:
  - new `src/tui/graphics/{kitty-native,kitty-core,kitty-terminal,native-image}.ts`
  - `src/tui-app.ts`: create the handle once per physical terminal, route BOTH
    screens through the facade, thread it to the five consumers, dispose with
    the app
  - the five media consumers + `visual-figure`/`image-workspace` plumbing
  - `docs/architecture/terminal-output.md`: the durable ownership contract
  - three new suites (protocol, owner, real-screen integration)
- Not changed / deferred:
  - no tmux pixel path, no new setting, no TSP change, no fork change
    (`packages/pi-tui/**` untouched), no Host/wire change
  - PR2 (tmux backend) and 7B (product tmux UX) remain separate stages

## Related work

Related: N/A (external plan/Stage-0 bundle; no repository issue owns this PR)

## Verification

| Check / environment | Result | Evidence / limitations |
| --- | --- | --- |
| Stage-0 E3, real Kitty 0.41.1 on WSL2/WSLg, 14 cases | PASS | real `TuiMainScreen`/`TuiAltScreen` + real facade/Core, raw outer bytes + screenshots, pinned to the PR head in `temp/image-7a-stage0/runner-env.json`; artifacts not committed |
| S0-1 valid line, Main hide/re-show without resize, multi-chunk quiet transmit | PASS | hide removes the placement in-frame, show re-places with no re-upload |
| S0-2 same Alt buffer, foreign and managed `d=I` both directions | PASS | foreign delete byte-identical, only its image leaves; core delete touches only its own id; `2J` control recorded separately |
| S0-3 automatic stop cleanup, re-entry ids, double stop | PASS | Alt releases its own ids before `terminal.stop()`; new id/placement on re-entry; Main never sends `d=I` |
| S0-4 `none`/`2J`/`3J`/`2J+3J` fresh states | PASS | measured: a bare `3J` invalidates data exactly like `2J`; re-transmit only after an invalidating clear |
| S0-5 permission trace + text/OSC invariance | PASS | no global delete on the wire; OSC 8/52/SGR byte-identical |
| S0-6 consumer sufficiency | PASS | public `Component` + `Terminal` suffice; no fork seam needed |
| S0-7 Main + leased Alt on one Core | PASS | Alt stop deletes only the alt id; Main's image stays visible with no re-transmit |
| Product-shaped consumers through the real factory | PASS | real `ImageThumbnail` + `ImageViewerPanel` on a real main screen |
| `pnpm typecheck` (fork + bundle + bench) | PASS | clean |
| New suites (protocol / owner / real-screen integration) | PASS | 43 tests |
| Affected client suites (thumbnail, draft, viewer, SVG, 6B, transcript) | PASS | run in the same batch |
| `pnpm verify:prepush` (fork/bundle/bench typecheck, fork suite, tmux, tooling, gates, audit, pack:release + the eight public-package smokes) | PASS | run on the PR head; see the verification comment |
| CI-skipped lanes (`compat:dsh:npm`, preset parity, remote d2-fork and session-lifecycle smokes), tarball `smoke:boundary` / `smoke:startup-strictness`, `git diff --check` | PASS | run locally on the PR head after the pipeline |
| Whole-application L6 session with real Host attachments | NOT_RUN | out of this PR's evidence scope; the E2 integration + real-GUI Stage-0 + product-shaped consumer cases cover the seam |
| Draft/SVG consumers inside a real Kitty window | NOT_VERIFIED | covered by the integration/unit suites only |

## Review trail

Independent reviewer (dedicated review route, high effort) ran seven rounds on
this branch; the final verdict on the head snapshot is **CLOSED**:

| Round | Finding | Disposition |
|---|---|---|
| 1 | Alt's global `d=A` freed Main images; a graphics command split inside `ESC _G` bypassed the gate; `preserveScreen`-driven Main cleanup | per-buffer residency; introducer/signal holdback; Owner-adjudicated terminal retention |
| 2 | a failed `write()` left the ledger believing bytes landed; the 32-id cap excluded retained ids | residency rollback + rethrow; retire take/commit/rollback; Owner replaced the cumulative cap with a working-set budget |
| 3 | a retained-id ring could forget an id (>256) and ids could be re-used | contiguous forward-only id range: exact ownership, O(1) memory, never wraps |
| 4 | stop cleanup deleted accounting before the write; foreign pass-through under the id scheme; ambiguous placement cleanup | cleanup goes through take/commit/rollback; ambiguous placements retained per the Owner ruling; foreign ids outside the range pass through byte-for-byte |
| 5 | Alt Viewer Esc→list then close left an Alt-painted id unreleased | per-alternate-session placement ownership, released on the alt screen's own global delete |
| 6 | an ordinary `2J` inside the alt session dropped that ownership | session lifetime split from residency (`beginAltSession`/`endAltSession`) |
| 7 | — | **CLOSED** |

The only item settled by adjudication rather than code is the ambiguous
placement: a write that threw after possibly painting is retained, never deleted
on a guess, because the Owner froze "an image that may be referenced by the
viewport or scrollback is never freed by Core cleanup".

## Risks and compatibility

- **Resource lifetime (Owner-adjudicated):** a painted image is
  terminal-retained — the Core drops its own payload and never hard-deletes it,
  because the pixels may still be in the viewport or scrollback. Main `stop()`
  never sends `d=I` in either `preserveScreen` mode; Alt releases the ids it
  placed, and only those. The terminal may keep that image data; this is the
  accepted cost of preserving today's visible behavior and is not claimed as
  reclaimed memory.
- **Budget:** only the Core's active working set is bounded (64 MiB base64
  payload cache, 256 MiB estimated decoded footprint). There is deliberately no
  cumulative id quota, so the 33rd/64th/100th image of a session never falls
  back because of the ones before it.
- **Ids:** a contiguous forward-only range from a random start; ownership is
  decidable in O(1), ids are never re-used, and the range never wraps
  (exhaustion falls back to text). A foreign id numerically coinciding with one
  of ours (probability ≈ allocated/2^32) would have its `d=I` run as the
  placement-removal part of the same request; the plan forbids claiming that
  probability is zero.
- **Write failure:** `Terminal.write()` is treated as an offer. A failing frame
  clears the touched images' residency and rethrows, so the next placement
  re-sends; queued retirements and the stop cleanup are take/commit/rollback so
  a failed write keeps the accounting; a failing cleanup still restores the
  terminal before it is reported. An ambiguous placement (the write threw after
  possibly painting) is retained, never deleted on a guess.
- **Compatibility:** iTerm2, Ghostty/WezTerm/Warp, tmux and unknown terminals
  keep the legacy `Image`/text fallback; a `PI_IMAGE_PROTOCOL` override cannot
  force admission. Rollback is a revert of this PR: the legacy paths are intact
  and no persisted state changed.

## Documentation

Decision: `DOC_UPDATED`

`docs/architecture/terminal-output.md` — the trusted Kitty command boundary now
names the single owner of image ids/data, the buffer-scoped translation of
legacy deletes, terminal retention of painted pixels, the working-set-only
budget and the write-is-an-offer rule.

## Final checks

- [x] The change stays within the stated scope; unrelated work is excluded.
- [x] Verification results and remaining limitations are accurately reported.
- [x] Related Issues are updated where applicable; PR completion and stage
      closure are distinguished.
